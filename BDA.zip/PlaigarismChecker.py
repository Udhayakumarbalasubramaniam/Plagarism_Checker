import streamlit as st
import requests
from bs4 import BeautifulSoup
from pymongo import MongoClient
from difflib import SequenceMatcher
import PyPDF2
from docx import Document

# MongoDB Atlas connection
MONGO_URI = "mongodb+srv://swetha_A:PlagiarismChecker@plagiarismcheckercluste.rkdn2.mongodb.net/?retryWrites=true&w=majority&appName=PlagiarismCheckerCluster"
client = MongoClient(MONGO_URI)
db = client['plagiarism_checker']
collection = db['documents']

# Function to calculate similarity
def calculate_similarity(text1, text2):
    return SequenceMatcher(None, text1, text2).ratio()

# Streamlit UI setup with custom styles
st.set_page_config(page_title="Plagiarism Checker", page_icon="📝", layout="wide")

# Background image URL (local or online image path)
background_image_url = "https://today.tamu.edu/wp-content/uploads/2021/06/GettyImages-1202271610.jpg"

# Custom CSS for UI styling
st.markdown(f"""
    <style>
        .stApp {{
            background-image: url("{background_image_url}");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: 'Arial', sans-serif;
        }}
        .title {{
            font-size: 42px;
            color: #FF6347;
            font-weight: bold;
            text-align: center;
            text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.7);
            margin-top: 30px;
        }}
        .css-1d391kg {{
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }}
        .sidebar-title {{
            font-size: 24px;
            color: #FF6347;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }}
        .output {{
            background-color: rgba(255, 255, 255, 0.8);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
            margin-top: 40px;
        }}
        .plagiarism-warning {{
            color: #FF4500;
            font-weight: bold;
            font-size: 18px;
        }}
        .plagiarism-moderate {{
            color: #FFD700;
            font-weight: bold;
            font-size: 18px;
        }}
        .plagiarism-low {{
            color: #32CD32;
            font-weight: bold;
            font-size: 18px;
        }}
    </style>
""", unsafe_allow_html=True)

# Title and description
st.markdown('<div class="title">Plagiarism Checker</div>', unsafe_allow_html=True)

# Function to extract text from PDF
def extract_text_from_pdf(pdf_file):
    reader = PyPDF2.PdfReader(pdf_file)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

# Function to extract text from Word documents
def extract_text_from_docx(docx_file):
    document = Document(docx_file)
    text = "\n".join([paragraph.text for paragraph in document.paragraphs])
    return text

# Sidebar inputs
with st.sidebar:
    st.markdown('<div class="sidebar-title">Upload or Paste Text</div>', unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload a Text, PDF, or Word File", type=["txt", "pdf", "docx"])
    input_text = st.text_area("Or, Paste the Text Here", height=150)

user_input = ""
if uploaded_file:
    if uploaded_file.name.endswith(".txt"):
        user_input = uploaded_file.getvalue().decode("utf-8")
    elif uploaded_file.name.endswith(".pdf"):
        user_input = extract_text_from_pdf(uploaded_file)
    elif uploaded_file.name.endswith(".docx"):
        user_input = extract_text_from_docx(uploaded_file)
elif input_text:
    user_input = input_text

# Plagiarism check
if st.sidebar.button("Check Plagiarism") and user_input:
    st.markdown('<div class="header">Results</div>', unsafe_allow_html=True)
    
    # Step 1: Retrieve all documents from MongoDB
    all_docs = list(collection.find())  # Retrieve all documents
    
    # Step 2: Calculate similarities
    similarities = []
    for doc in all_docs:
        similarity = calculate_similarity(user_input, doc['content'])
        similarities.append({"doc_id": doc["_id"], "similarity": similarity})
    
    # Step 3: Display results
    if similarities:
        max_similarity = max(similarities, key=lambda x: x["similarity"])
        max_percentage = max_similarity["similarity"] * 100  # Convert to percentage
        
        st.write(f"### Plagiarism Percentage: {max_percentage:.2f}%")
        
        # Feedback based on similarity
        if max_percentage > 70:
            st.markdown('<p class="plagiarism-warning">⚠️ High plagiarism detected! Consider rephrasing.</p>', unsafe_allow_html=True)
        elif max_percentage > 40:
            st.markdown('<p class="plagiarism-moderate">⚠️ Moderate plagiarism detected. Review your content.</p>', unsafe_allow_html=True)
        else:
            st.markdown('<p class="plagiarism-low">✅ Low plagiarism detected. Your content is unique!</p>', unsafe_allow_html=True)
    else:
        st.write("No documents found in the database for comparison.")

else:
    st.sidebar.write("Please upload a file or paste text to proceed.")