from pyspark.sql import SparkSession
from pyspark.sql.functions import col, current_timestamp, lit
import requests
from pyspark.sql.types import StringType, StructType, StructField
import PyPDF2
from docx import Document

# Initialize SparkSession with MongoDB connector
spark = SparkSession.builder \
    .appName("APIFetchWithSpark") \
    .config("spark.mongodb.input.uri", "mongodb+srv://swethaanand42:FIPZvDrji9pETrtp@plagiarismcheckercluste.wiqhe.mongodb.net/Clusters.PlagiarismCheckerCollection") \
    .config("spark.mongodb.output.uri", "mongodb+srv://swethaanand42:FIPZvDrji9pETrtp@plagiarismcheckercluste.wiqhe.mongodb.net/Clusters.PlagiarismCheckerCollection") \
    .getOrCreate()

# Scholarly or Semantic Scholar API Key and Endpoint
API_KEY = "your_semantic_scholar_api_key"  # Replace with your actual API key
BASE_URL = "https://api.semanticscholar.org/graph/v1/paper/search"

# Function to fetch data using Semantic Scholar API
def fetch_data(query, limit=10):
    try:
        params = {
            "query": query,
            "limit": limit,
            "fields": "title,url"
        }
        headers = {"x-api-key": API_KEY}
        response = requests.get(BASE_URL, headers=headers, params=params)
        response.raise_for_status()
        papers = response.json().get("data", [])
        data = [{"url": paper.get("url", ""), "title": paper.get("title", "")} for paper in papers]
        return data
    except requests.exceptions.RequestException as e:
        print(f"Error while fetching data for query '{query}': {e}")
        return []

# Function to extract text from PDF
def extract_text_from_pdf(pdf_file_path):
    try:
        with open(pdf_file_path, "rb") as pdf_file:
            reader = PyPDF2.PdfReader(pdf_file)
            text = ""
            for page in reader.pages:
                text += page.extract_text()
            return text
    except Exception as e:
        print(f"Error extracting text from PDF: {e}")
        return ""

# Function to extract text from DOCX
def extract_text_from_docx(docx_file_path):
    try:
        document = Document(docx_file_path)
        text = "\n".join([paragraph.text for paragraph in document.paragraphs])
        return text
    except Exception as e:
        print(f"Error extracting text from DOCX: {e}")
        return ""

# Function to calculate similarity (if needed for custom algorithms)
def calculate_similarity(text1, text2):
    from difflib import SequenceMatcher
    return SequenceMatcher(None, text1, text2).ratio()

# User input handling
input_type = input("Enter the type of input (query, pdf, docx): ").strip().lower()
user_input = ""

if input_type == "query":
    user_input = input("Enter your query: ").strip()
    queries = [user_input]
elif input_type == "pdf":
    pdf_path = input("Enter the path to the PDF file: ").strip()
    user_input = extract_text_from_pdf(pdf_path)
    queries = [user_input]  # Process the text as a query
elif input_type == "docx":
    docx_path = input("Enter the path to the DOCX file: ").strip()
    user_input = extract_text_from_docx(docx_path)
    queries = [user_input]  # Process the text as a query
else:
    print("Invalid input type. Exiting.")
    exit()

# Fetch data for all queries or process user input
fetched_data = []
for query in queries:
    fetched_data.extend(fetch_data(query))

# Create a schema for the DataFrame
schema = StructType([
    StructField("title", StringType(), True),
    StructField("url", StringType(), True)
])

# Convert fetched data into a Spark DataFrame
df = spark.createDataFrame(fetched_data, schema=schema)

# Add user input and timestamp
df = df.withColumn("user_input", lit(user_input)) \
       .withColumn("scraped_at", current_timestamp())

# Show the DataFrame (optional)
df.show(truncate=False)

# Write data to MongoDB
df.write.format("mongo").mode("append").save()

print("Data has been written to MongoDB successfully.")

# Load data back from MongoDB for additional processing
df_from_mongo = spark.read.format("mongo").load()

# Example processing: Filter based on a condition
processed_df = df_from_mongo.filter(col("url").contains("bbc"))
processed_df.show()

# Stop the Spark session
spark.stop()
